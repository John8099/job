<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
 
 <style>
    }
.logo{
                background-color: lightgray;
                margin-bottom: 50px;
                
                margin-top: 10px;
                
            }

.nab{
                float: left;
                
}
.log{
                font-size: 30px;
                padding-left: 40px;
                font-weight: bold;
                font-family: calibri;
}
.nav{
                float: right;
                padding-top: 30px;

}

.leg{
                padding-right: 50px;
                font-family: calibri;
                text-decoration: none;
                font-size: 20px;
                color: black;

}




 </style>
<div class="logo">
    <div class="nab">
        <p class="log">Job Finder</p>
    </div>
    <div class="nav">
        <a href="admin-list.php" class="leg">Admin List</a>
        <a href="applicants-list.php" class="leg">Applicants List</a>
        <a href="employer-list.php" class="leg">Employer List</a>
        <a href="category-list.php" class="leg">Category List</a>
        <a href="add-admin.php" class="leg">Add Admin</a>
        <a href="add-category.php" class="leg">Add Category</a>
        <a href="../back/logout.php" class="leg">Logout</a>
    </div>
</div>

       
</body>
</html>
